CREATE VIEW mars_all_id AS WITH c1 AS (
         SELECT r.date,
            r.actual_date,
            c.cat1_id,
            c.category_1,
            r.category_2,
            r.product_name,
            r.quantity,
            r.price,
            r.predacvbasevol,
            r.effect_coupon,
            r.effect_debut,
            r.effect_discount,
            r.effect_ln_baseprice,
            r.other,
            r.actual
           FROM (stg.d_mars_final_result r
             LEFT JOIN stg.mars_category_1 c ON ((r.category_1 = c.category_1)))
        ), c2 AS (
         SELECT c.date,
            c.actual_date,
            c.cat1_id,
            c.category_1,
            m.cat2_id,
            m.category_2,
            c.product_name,
            c.quantity,
            c.price,
            c.predacvbasevol,
            c.effect_coupon,
            c.effect_debut,
            c.effect_discount,
            c.effect_ln_baseprice,
            c.other,
            c.actual
           FROM (c1 c
             LEFT JOIN stg.mars_category_2 m ON ((c.category_2 = m.category_2)))
        ), pro AS (
         SELECT c.date,
            c.actual_date,
            c.cat1_id,
            c.category_1,
            c.cat2_id,
            c.category_2,
            n.ppg_id,
            n.product_name,
            c.quantity,
            c.price,
            c.predacvbasevol,
            c.effect_coupon,
            c.effect_debut,
            c.effect_discount,
            c.effect_ln_baseprice,
            c.other,
            c.actual
           FROM (c2 c
             LEFT JOIN stg.mars_product_name n ON ((c.product_name = n.product_name)))
        )
 SELECT pro.date,
    pro.actual_date,
    pro.cat1_id,
    pro.category_1,
    pro.cat2_id,
    pro.category_2,
    pro.ppg_id,
    pro.product_name,
    pro.quantity,
    pro.price,
    pro.predacvbasevol,
    pro.effect_coupon,
    pro.effect_debut,
    pro.effect_discount,
    pro.effect_ln_baseprice,
    pro.other,
    pro.actual
   FROM pro;
