CREATE VIEW dp_bolome_order AS SELECT ods.dw_dt,
    ods.pay_date,
    ods.user_id,
    ods.order_id,
    ods.barcode,
    ods.quantity,
    ods.price,
    ods.warehouse_id,
    ods.show_id,
    ods.preview_show_id,
    ods.replay_show_id,
    ods.coupon_id,
    ods.event_id,
    ods.copon_discount_amount,
    ods.system_discount_amount,
    ods.tax_amount,
    ods.logistics_amount
   FROM (ods.d_bolome_order ods
     JOIN stg.d_bolome_order_rng rng ON ((((ods.dw_dt >= rng.dw_start_dt) AND (ods.dw_dt <= rng.dw_end_dt)) AND (rng.dw_in_use = '1'::bpchar))));
