CREATE VIEW dp_jushuitan_detail AS SELECT ods.dw_dt,
    ods.dw_ts,
    ods.oi_id,
    ods.o_id,
    ods.sku_id,
    ods.qty,
    ods.price,
    ods.name
   FROM (ods.d_jushuitan_detail ods
     JOIN stg.d_jushuitan_detail_rng rng ON ((((ods.dw_dt >= rng.dw_start_dt) AND (ods.dw_dt <= rng.dw_end_dt)) AND (rng.dw_in_use = '1'::bpchar))));
