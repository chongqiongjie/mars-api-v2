CREATE VIEW dp_jushuitan_inventory AS SELECT ods.dw_dt,
    ods.dw_ts,
    ods.xdate,
    ods.sku_id,
    ods.inventory
   FROM (ods.d_jushuitan_inventory ods
     JOIN stg.d_jushuitan_inventory_rng rng ON ((((ods.dw_dt >= rng.dw_start_dt) AND (ods.dw_dt <= rng.dw_end_dt)) AND (rng.dw_in_use = '1'::bpchar))));
