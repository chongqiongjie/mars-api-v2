CREATE VIEW dp_jushuitan_order AS SELECT ods.dw_dt,
    ods.dw_ts,
    ods.o_id,
    ods.order_date,
    ods.shop_buyer_id,
    ods.shop_name,
    ods.pay_amount,
    ods.status,
    ods.send_date,
    ods.receiver_state
   FROM (ods.d_jushuitan_order ods
     JOIN stg.d_jushuitan_order_rng rng ON ((((ods.dw_dt >= rng.dw_start_dt) AND (ods.dw_dt <= rng.dw_end_dt)) AND (rng.dw_in_use = '1'::bpchar))));
